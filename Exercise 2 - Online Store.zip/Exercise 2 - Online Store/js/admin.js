

function init(){
    $('#btn-register').on('click',function(){register();})
}
let items=[];

class Item{
    constructor(code,title,price,description,category,image){
        this.code = code;
        this.title = title;
        this.price = price;
        this.description = description;
        this.category = category;
        this.image = image;
    }
}

function register(){
    //save the input values into variables
    var code = $('#code').val();
    var title = $('#title').val();
    var price= $('#price').val();
    var description = $('#description').val();
    var category = $('#category').val();
    var image = $('#image').val();
    var newItem = new Item(code,title,price,description,category,image);

    items.push(newItem);
    console.log(newItem);
    console.log(items);
    clearForm();

}

function clearForm(){
    var code = $('#code').val();
    var title = $('#title').val();
    var price = $('#price').val();
    var description = $('#description').val();
    var category = $('#category').val();
    var image = $('#image').val();
}


window.onload=init;