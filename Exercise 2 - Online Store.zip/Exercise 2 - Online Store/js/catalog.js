

let items=[
    {
        code: '123',
        title: 'Desktop Computer',
        price: 2000,
        description: 'Computer for modern workloads',
        category: 'Computers',
        image: 'https://i.dell.com/das/dih.ashx/527x340/sites/csimages/app-merchandizing_images/all/xps-tower-geforce.png'
    },
    {
        code: '124',
        title: 'Knife Set',
        price: 250,
        description: 'Fancy chef knife set',
        category: 'Housewares',
        image: 'https://secure.img1-fg.wfcdn.com/im/59538211/resize-h800%5Ecompr-r85/1108/11086804/Wusthof+Gourmet+18+Piece+Knife+Block+Set.jpg'
    },
    {
        code: '125',
        title: 'Coffee Table',
        price: 1599,
        description: 'A quality wood table',
        category: 'Furniture',
        image: 'https://secure.img1-ag.wfcdn.com/im/28439128/resize-h800%5Ecompr-r85/7292/72927853/Thornhill+Coffee+Table+with+Storage.jpg'
    }
];

function displayProduct(){
    //travel array
    //$('#list-items').val();
    for(i=0;i<items.length;i++){
        let displayed = items[i];
       console.log(displayed);
       var layout = ` <div id="${displayed.code}"> 
                            <img src="${displayed.image}">
                            <h4>${displayed.title}</h4>
                            <h5>$${displayed.price}</h5>
                            <p>${displayed.description}</p>
                            <div>
                                <button>Add to Cart</button>
                            </div>
                      </div>
       
       `;
       console.log(i,layout);
       $('#catalog').append(layout);
    }
  
    //display on the DOM
   
}

function init(){
    displayProduct();
}

window.onload=init;
